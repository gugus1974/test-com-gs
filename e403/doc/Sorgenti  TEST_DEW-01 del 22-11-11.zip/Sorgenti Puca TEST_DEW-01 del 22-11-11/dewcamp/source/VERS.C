unsigned char *vers6 ="DEW Stim 2.00 21/11/2011";       
